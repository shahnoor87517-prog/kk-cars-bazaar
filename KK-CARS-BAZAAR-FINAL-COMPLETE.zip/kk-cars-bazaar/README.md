# KK CARS BAZAAR — Final Project

Complete React + Vite dealership website with a public customer site and protected owner dashboard.

## Public
- Home, About, Vehicles, Finance, Contact
- Category browsing: 4 WHEELER, 2 WHEELER, TAMPO, TRUCK / DUMPER
- Live vehicle listings from Supabase
- Vehicle detail pages with photo gallery
- Call, WhatsApp and Google Maps actions
- Responsive mobile/tablet/desktop design

## Owner dashboard
Open `/admin` after deployment.
- Supabase email/password authentication
- `admin_users` authorization gate
- Add/edit/delete vehicles
- Multiple vehicle photo upload
- Publish/draft and Available/Reserved/Sold status
- Finance availability
- Dashboard inventory counters by category

## Supabase setup
1. Create a Supabase project.
2. Run `supabase/schema.sql` in Supabase SQL Editor.
3. Create an Auth user for the owner.
4. Copy that user's UUID into the final `admin_users` INSERT at the bottom of `schema.sql` and run it.
5. Copy `.env.example` to `.env` and set `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY`.
6. `npm install`
7. `npm run dev` or `npm run build`

Never put a Supabase service-role key in the frontend.
