import { MapPin, Phone, MessageCircle } from "lucide-react";
import { business } from "../lib/data";

export default function Footer() {
  return <footer className="footer">
    <div className="container footer-grid">
      <div>
        <img className="footer-logo" src="/logo.svg" alt="KK CARS BAZAAR"/>
        <p className="muted">Pre-owned vehicles with a straightforward, customer-first enquiry experience.</p>
      </div>
      <div>
        <h4>Visit</h4>
        <p><MapPin size={16}/> {business.address}</p>
      </div>
      <div>
        <h4>Contact</h4>
        <a href={`tel:${business.phone1}`}><Phone size={16}/> {business.phone1}</a>
        <a href={`tel:${business.phone2}`}><Phone size={16}/> {business.phone2}</a>
        <a href={`https://wa.me/${business.whatsapp}`} target="_blank" rel="noreferrer"><MessageCircle size={16}/> WhatsApp</a>
      </div>
    </div>
    <div className="container footer-bottom">
      <span>© 2026 KK CARS BAZAAR. All Rights Reserved.</span>
      <span>Creating by: Noor Shah</span>
    </div>
  </footer>;
}