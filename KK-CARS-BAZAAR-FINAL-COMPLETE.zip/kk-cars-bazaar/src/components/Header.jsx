import { Link, useLocation } from "react-router-dom";
import { Menu, X, Phone, MessageCircle } from "lucide-react";
import { useState } from "react";
import { business } from "../lib/data";

export default function Header() {
  const [open, setOpen] = useState(false);
  const location = useLocation();
  const nav = [["/", "Home"], ["/vehicles", "Inventory"], ["/about", "About"], ["/finance", "Finance"], ["/contact", "Contact"]];

  return <header className="site-header">
    <div className="container header-inner">
      <Link to="/" className="brand" onClick={() => setOpen(false)}>
        <img src="/logo.svg" alt="KK CARS BAZAAR" />
      </Link>
      <nav className={open ? "nav open" : "nav"}>
        {nav.map(([to, label]) => <Link key={to} className={location.pathname === to ? "active" : ""} to={to} onClick={() => setOpen(false)}>{label}</Link>)}
      </nav>
      <div className="header-actions">
        <a className="icon-link" href={`tel:${business.phone1}`} aria-label="Call"><Phone size={18}/></a>
        <a className="icon-link whatsapp" href={`https://wa.me/${business.whatsapp}`} target="_blank" rel="noreferrer" aria-label="WhatsApp"><MessageCircle size={18}/></a>
        <button className="menu-btn" onClick={() => setOpen(v => !v)} aria-label="Menu">{open ? <X/> : <Menu/>}</button>
      </div>
    </div>
  </header>;
}