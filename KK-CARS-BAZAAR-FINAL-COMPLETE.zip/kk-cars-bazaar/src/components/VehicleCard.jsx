import { Link } from "react-router-dom";
import { ArrowUpRight } from "lucide-react";

export default function VehicleCard({ vehicle, showPrice=false }) {
  const image = vehicle.cover_url || vehicle.image_url;
  return <article className="vehicle-card">
    <Link to={`/vehicles/${vehicle.id}`} className="vehicle-image">
      {image ? <img src={image} alt={`${vehicle.make} ${vehicle.model}`} loading="lazy"/> : <div className="image-placeholder">KK CARS</div>}
      <span className={`status status-${String(vehicle.status || "AVAILABLE").toLowerCase()}`}>{vehicle.status || "AVAILABLE"}</span>
    </Link>
    <div className="vehicle-body">
      <div className="vehicle-meta">{vehicle.year || "—"} · {vehicle.category || "Vehicle"}</div>
      <h3>{vehicle.make} {vehicle.model}</h3>
      <p>{vehicle.variant || "Pre-owned vehicle"}{vehicle.fuel ? ` · ${vehicle.fuel}` : ""}</p>
      {showPrice && vehicle.price ? <strong className="vehicle-price">₹{Number(vehicle.price).toLocaleString("en-IN")}</strong> : null}
      <Link className="text-link" to={`/vehicles/${vehicle.id}`}>View details <ArrowUpRight size={16}/></Link>
    </div>
  </article>;
}