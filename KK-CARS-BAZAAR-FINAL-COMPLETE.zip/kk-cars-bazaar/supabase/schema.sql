-- KK CARS BAZAAR database + RLS
create extension if not exists pgcrypto;

create table if not exists public.admin_users (
  user_id uuid primary key references auth.users(id) on delete cascade,
  role text not null default 'owner' check (role in ('owner','staff')),
  created_at timestamptz not null default now()
);

create or replace function public.is_admin()
returns boolean
language sql
security definer
set search_path = public
as $$
  select exists(select 1 from public.admin_users where user_id = auth.uid());
$$;

create table if not exists public.site_settings (
  id bigint primary key default 1 check (id = 1),
  business_name text not null default 'KK CARS BAZAAR',
  address text not null default 'Ajanta Chowk, Jalgaon, Maharashtra, India',
  phone1 text not null default '9511676866',
  phone2 text not null default '8087632116',
  whatsapp_number text not null default '919511676866',
  owner_name text not null default 'Khalid Shah',
  team jsonb not null default '["Khalid Shah — Owner","Aawesh Shah","Danish Shah","Noor Shah"]'::jsonb,
  show_public_prices boolean not null default false,
  updated_at timestamptz not null default now()
);

insert into public.site_settings (id) values (1) on conflict (id) do nothing;

create table if not exists public.vehicles (
  id uuid primary key default gen_random_uuid(),
  make text not null,
  model text not null,
  variant text,
  year int check (year between 1980 and 2100),
  category text not null check (category in ('4 WHEELER','2 WHEELER','TAMPO','TRUCK / DUMPER')),
  fuel text check (fuel in ('PETROL','DIESEL','CNG','HYBRID','ELECTRIC')),
  transmission text check (transmission in ('MANUAL','AUTOMATIC','AMT','CVT','DCT')),
  km_driven int check (km_driven is null or km_driven >= 0),
  owners int check (owners is null or owners >= 0),
  registration_city text,
  price numeric(14,2),
  finance_available boolean not null default true,
  status text not null default 'AVAILABLE' check (status in ('AVAILABLE','RESERVED','SOLD')),
  description text,
  is_published boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.vehicle_images (
  id uuid primary key default gen_random_uuid(),
  vehicle_id uuid not null references public.vehicles(id) on delete cascade,
  storage_path text not null unique,
  public_url text not null,
  is_cover boolean not null default false,
  sort_order int not null default 0,
  created_at timestamptz not null default now()
);

alter table public.admin_users enable row level security;
alter table public.site_settings enable row level security;
alter table public.vehicles enable row level security;
alter table public.vehicle_images enable row level security;

drop policy if exists "public settings read" on public.site_settings;
create policy "public settings read" on public.site_settings for select using (true);
drop policy if exists "admin settings write" on public.site_settings;
create policy "admin settings write" on public.site_settings for all using (public.is_admin()) with check (public.is_admin());

drop policy if exists "public published vehicles read" on public.vehicles;
create policy "public published vehicles read" on public.vehicles for select using (is_published = true or public.is_admin());
drop policy if exists "admin vehicles write" on public.vehicles;
create policy "admin vehicles write" on public.vehicles for all using (public.is_admin()) with check (public.is_admin());

drop policy if exists "public images read" on public.vehicle_images;
create policy "public images read" on public.vehicle_images for select using (
  exists(select 1 from public.vehicles v where v.id = vehicle_id and (v.is_published = true or public.is_admin()))
);
drop policy if exists "admin images write" on public.vehicle_images;
create policy "admin images write" on public.vehicle_images for all using (public.is_admin()) with check (public.is_admin());

drop policy if exists "admin users self read" on public.admin_users;
create policy "admin users self read" on public.admin_users for select using (user_id = auth.uid() or public.is_admin());
drop policy if exists "admin users admin write" on public.admin_users;
create policy "admin users admin write" on public.admin_users for all using (public.is_admin()) with check (public.is_admin());

-- Storage bucket for public vehicle photos.
insert into storage.buckets (id, name, public) values ('vehicle-images','vehicle-images',true)
on conflict (id) do update set public = true;

drop policy if exists "public vehicle image read" on storage.objects;
create policy "public vehicle image read" on storage.objects for select using (bucket_id = 'vehicle-images');

drop policy if exists "admin vehicle image insert" on storage.objects;
create policy "admin vehicle image insert" on storage.objects for insert to authenticated
with check (bucket_id = 'vehicle-images' and public.is_admin());

drop policy if exists "admin vehicle image update" on storage.objects;
create policy "admin vehicle image update" on storage.objects for update to authenticated
using (bucket_id = 'vehicle-images' and public.is_admin())
with check (bucket_id = 'vehicle-images' and public.is_admin());

drop policy if exists "admin vehicle image delete" on storage.objects;
create policy "admin vehicle image delete" on storage.objects for delete to authenticated
using (bucket_id = 'vehicle-images' and public.is_admin());

-- After creating the owner's Auth user, run:
-- insert into public.admin_users(user_id, role) values ('YOUR_AUTH_USER_UUID','owner');
