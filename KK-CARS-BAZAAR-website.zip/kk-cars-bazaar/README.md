# KK CARS BAZAAR

Production-oriented React/Vite + Supabase dealership website.

## Included

- Premium dark charcoal / black / gold automotive design
- Responsive customer website
- Home, Inventory, Vehicle Detail, About, Finance, Contact
- Search + category + status filters
- Call and WhatsApp actions
- Google Maps action
- Private `/admin` owner dashboard
- Supabase email/password authentication
- Server-side authorization through `admin_users` + RLS
- Vehicle CRUD
- Multiple mobile photo upload
- First uploaded photo becomes cover
- Public/draft publishing control
- SOLD / RESERVED / AVAILABLE status
- Price stored in DB but hidden publicly by default
- Supabase Storage for vehicle images
- No invented dealership phone numbers or business claims

## Run locally

1. Install Node.js 20+.
2. Copy `.env.example` to `.env`.
3. Create a Supabase project.
4. Open Supabase SQL Editor and run `supabase/schema.sql`.
5. In Supabase Authentication, create the owner's email/password user.
6. Copy that user's UUID and run the final `insert into public.admin_users...` statement in the SQL editor.
7. Put your Supabase URL and anon key in `.env`.
8. Run:

```bash
npm install
npm run dev
```

Open the URL Vite prints.

## Deploy

This project is Vercel/Netlify friendly.

Build command:
`npm run build`

Publish directory:
`dist`

Add the same environment variables in the hosting provider.

## Important

The public inventory is intentionally empty until you add real dealership vehicles through `/admin`. The website does not ship with fabricated vehicle listings, prices, reviews, awards, or extra contact numbers.

For a real production deployment, keep the Supabase anon key in the frontend environment only; never expose a Supabase service-role key in Vite or client code.
