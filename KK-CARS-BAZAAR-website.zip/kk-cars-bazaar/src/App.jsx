import { BrowserRouter, Routes, Route, Link, useNavigate, useParams, useSearchParams } from "react-router-dom";
import { useEffect, useMemo, useState } from "react";
import { ArrowRight, CheckCircle2, ChevronRight, Filter, MapPin, Phone, Search, ShieldCheck, Sparkles, Upload, Trash2, LogOut, Plus, Save } from "lucide-react";
import Header from "./components/Header";
import Footer from "./components/Footer";
import VehicleCard from "./components/VehicleCard";
import { business, categories, whyUs } from "./lib/data";
import { supabase, supabaseConfigured } from "./lib/supabase";
import "./styles.css";

const demoEmpty = [];

async function getSettings() {
  if (!supabaseConfigured) return { show_public_prices: false };
  const { data } = await supabase.from("site_settings").select("*").eq("id", 1).maybeSingle();
  return data || { show_public_prices: false };
}

async function getVehicles(filters={}) {
  if (!supabaseConfigured) return demoEmpty;
  let q = supabase.from("vehicles").select("*, vehicle_images(*)").eq("is_published", true).order("created_at", {ascending:false});
  if (filters.category && filters.category !== "ALL") q = q.eq("category", filters.category);
  if (filters.status && filters.status !== "ALL") q = q.eq("status", filters.status);
  if (filters.search) q = q.or(`make.ilike.%${filters.search}%,model.ilike.%${filters.search}%,variant.ilike.%${filters.search}%`);
  const { data, error } = await q;
  if (error) throw error;
  return (data || []).map(v => ({...v, cover_url: v.vehicle_images?.find(i => i.is_cover)?.public_url || v.vehicle_images?.[0]?.public_url}));
}

function Layout({children}) { return <><Header/><main>{children}</main><Footer/></>; }

function Home() {
  const [vehicles, setVehicles] = useState([]);
  const [settings, setSettings] = useState({show_public_prices:false});
  useEffect(() => { getVehicles().then(setVehicles).catch(()=>setVehicles([])); getSettings().then(setSettings); }, []);
  return <Layout>
    <section className="hero">
      <div className="hero-overlay"/>
      <div className="container hero-content">
        <div className="eyebrow"><Sparkles size={15}/> PRE-OWNED VEHICLES · JALGAON</div>
        <h1>Find a car that<br/><span>feels right.</span></h1>
        <p>Explore professionally presented pre-owned vehicles at KK CARS BAZAAR, Ajanta Chowk, Jalgaon.</p>
        <div className="hero-buttons"><Link className="btn gold" to="/vehicles">Explore Inventory <ArrowRight size={18}/></Link><a className="btn outline" href={`https://wa.me/${business.whatsapp}`} target="_blank" rel="noreferrer">WhatsApp Us</a></div>
      </div>
      <div className="hero-scroll">SCROLL TO EXPLORE <span/></div>
    </section>

    <section className="trust-bar"><div className="container trust-grid">
      {["Direct Dealership Contact","Vehicle Details Online","Call & WhatsApp Enquiry","Ajanta Chowk, Jalgaon"].map((x,i)=><div key={x}><CheckCircle2 size={18}/><span>{x}</span></div>)}
    </div></section>

    <section className="section"><div className="container">
      <SectionHeading kicker="THE COLLECTION" title="Browse by category" text="Choose a body style and explore the current dealership inventory."/>
      <div className="category-grid">{categories.map(c=><Link key={c.key} to={`/vehicles?category=${c.key}`} className="category-card">
        <img src={c.image} alt={c.title} loading="lazy"/><div className="category-shade"/><div className="category-label"><span>{c.title}</span><ChevronRight/></div>
      </Link>)}</div>
    </div></section>

    <section className="split-banner"><div className="container split-inner">
      <div><div className="eyebrow">FINANCE SUPPORT</div><h2>Take the next step with confidence.</h2><p>Ask our team about finance options and the documentation needed for your vehicle enquiry.</p></div>
      <Link className="btn gold" to="/finance">Finance Details <ArrowRight size={18}/></Link>
    </div></section>

    <section className="section"><div className="container">
      <SectionHeading kicker="WHY KK CARS" title="A simpler way to buy pre-owned" text="Clear information, direct communication and a local showroom you can visit."/>
      <div className="why-grid">{whyUs.map(([n,t,d])=><div className="why-card" key={n}><span>{n}</span><ShieldCheck size={22}/><h3>{t}</h3><p>{d}</p></div>)}</div>
    </div></section>

    <section className="section dark-section"><div className="container about-grid">
      <div><div className="eyebrow">MEET THE TEAM</div><h2>Local people.<br/>Straight answers.</h2></div>
      <div><p className="large">KK CARS BAZAAR is led by <strong>{business.owner}</strong>, with a team focused on helping customers understand the vehicle, enquiry and finance process.</p><div className="team-list">{business.team.map(t=><div key={t}><CheckCircle2 size={16}/>{t}</div>)}</div><Link className="text-link light" to="/about">About the dealership <ArrowRight size={16}/></Link></div>
    </div></section>

    <section className="section"><div className="container cta-box">
      <div><div className="eyebrow">VISIT THE SHOWROOM</div><h2>See a vehicle in person.</h2><p>{business.address}</p></div>
      <div className="cta-actions"><a className="btn dark" href={`tel:${business.phone1}`}>Call {business.phone1}</a><a className="btn gold" href={`https://wa.me/${business.whatsapp}`} target="_blank" rel="noreferrer">WhatsApp</a></div>
    </div></section>
  </Layout>;
}

function SectionHeading({kicker,title,text}) { return <div className="section-heading"><div className="eyebrow">{kicker}</div><h2>{title}</h2>{text && <p>{text}</p>}</div>; }

function Vehicles() {
  const [params,setParams] = useSearchParams();
  const [vehicles,setVehicles] = useState([]);
  const [loading,setLoading] = useState(true);
  const [settings,setSettings] = useState({show_public_prices:false});
  const [search,setSearch] = useState(params.get("search")||"");
  const category=params.get("category")||"ALL";
  const status=params.get("status")||"ALL";
  const load=()=>{setLoading(true); Promise.all([getVehicles({category,status,search}),getSettings()]).then(([v,s])=>{setVehicles(v);setSettings(s)}).finally(()=>setLoading(false));};
  useEffect(load,[category,status]);
  return <Layout><section className="page-hero"><div className="container"><div className="eyebrow">KK CARS BAZAAR</div><h1>Our inventory</h1><p>Browse the vehicles currently published by the dealership.</p></div></section>
    <section className="section"><div className="container">
      <div className="filters">
        <form onSubmit={e=>{e.preventDefault();setParams(p=>{p.set("search",search);return p});load()}} className="search-box"><Search size={18}/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search make, model or variant"/><button>Search</button></form>
        <select value={category} onChange={e=>setParams(p=>{p.set("category",e.target.value);return p})}><option value="ALL">All categories</option>{categories.map(c=><option key={c.key} value={c.key}>{c.title}</option>)}</select>
        <select value={status} onChange={e=>setParams(p=>{p.set("status",e.target.value);return p})}><option value="ALL">All status</option><option value="AVAILABLE">Available</option><option value="RESERVED">Reserved</option><option value="SOLD">Sold</option></select>
      </div>
      {!supabaseConfigured && <EmptyNotice title="Inventory is ready to connect" text="Add your Supabase project values to .env, run the included SQL, then publish vehicles from /admin."/>}
      {loading ? <div className="loading-grid">{[1,2,3].map(i=><div className="skeleton" key={i}/>)}</div> : vehicles.length ? <div className="vehicle-grid">{vehicles.map(v=><VehicleCard key={v.id} vehicle={v} showPrice={settings.show_public_prices}/>)}</div> : supabaseConfigured ? <EmptyNotice title="No published vehicles yet" text="Vehicles added through the owner dashboard will appear here."/> : null}
    </div></section>
  </Layout>;
}

function EmptyNotice({title,text}) { return <div className="empty"><Filter size={22}/><h3>{title}</h3><p>{text}</p></div>; }

function VehicleDetail() {
  const {id}=useParams(); const [v,setV]=useState(null); const [settings,setSettings]=useState({show_public_prices:false});
  useEffect(()=>{if(!supabaseConfigured)return; supabase.from("vehicles").select("*, vehicle_images(*)").eq("id",id).eq("is_published",true).single().then(({data})=>{if(data)setV({...data,cover_url:data.vehicle_images?.find(i=>i.is_cover)?.public_url})});getSettings().then(setSettings)},[id]);
  if(!supabaseConfigured) return <Layout><section className="page-hero"><div className="container"><div className="eyebrow">VEHICLE DETAILS</div><h1>Connect inventory first</h1><p>This page becomes live automatically when a published vehicle exists in Supabase.</p></div></section></Layout>;
  if(!v) return <Layout><section className="section"><div className="container empty"><h3>Vehicle not found</h3><Link className="btn dark" to="/vehicles">Back to inventory</Link></div></section></Layout>;
  const imgs=(v.vehicle_images||[]).sort((a,b)=>(b.is_cover?1:0)-(a.is_cover?1:0));
  return <Layout><section className="section vehicle-detail"><div className="container">
    <Link className="back-link" to="/vehicles">← Back to inventory</Link>
    <div className="detail-grid"><div><div className="main-photo">{v.cover_url?<img src={v.cover_url} alt={`${v.make} ${v.model}`}/>:<div className="image-placeholder">KK CARS</div>}</div><div className="thumbs">{imgs.map(i=><img key={i.id} src={i.public_url} alt="" />)}</div></div>
    <div className="detail-copy"><div className="status-row"><span className="status">{v.status}</span><span>{v.year} · {v.category}</span></div><h1>{v.make} {v.model}</h1><p className="detail-variant">{v.variant}</p>{settings.show_public_prices&&v.price?<div className="detail-price">₹{Number(v.price).toLocaleString("en-IN")}</div>:null}<div className="spec-grid">{[["Year",v.year],["Fuel",v.fuel],["Transmission",v.transmission],["KM Driven",v.km_driven],["Owners",v.owners],["Registration",v.registration_city]].map(([a,b])=><div key={a}><span>{a}</span><strong>{b||"—"}</strong></div>)}</div><p>{v.description||"Contact the dealership for full vehicle details and an in-person viewing."}</p><div className="cta-actions"><a className="btn dark" href={`tel:${business.phone1}`}><Phone size={17}/> Call</a><a className="btn gold" href={`https://wa.me/${business.whatsapp}?text=${encodeURIComponent(`Hello KK CARS BAZAAR, I am interested in the ${v.year||""} ${v.make||""} ${v.model||""}.`)}`} target="_blank" rel="noreferrer">WhatsApp</a></div></div></div>
  </div></section></Layout>;
}

function SimplePage({type}) {
  const content = {
    about:["About KK CARS BAZAAR","A local pre-owned vehicle dealership at Ajanta Chowk, Jalgaon.","Our team", business.team],
    finance:["Finance","Finance support for your vehicle enquiry.","How it works",["Choose a vehicle","Share your basic enquiry details","Discuss available finance options with the dealership","Complete lender documentation as applicable"]],
    contact:["Contact","Visit the showroom or speak directly with the dealership.","Contact details",[business.address,business.phone1,business.phone2]]
  }[type];
  return <Layout><section className="page-hero"><div className="container"><div className="eyebrow">KK CARS BAZAAR</div><h1>{content[0]}</h1><p>{content[1]}</p></div></section><section className="section"><div className="container simple-grid"><div><div className="eyebrow">{content[2]}</div><h2>{type==="about"?"People behind the showroom":type==="finance"?"A clear enquiry flow":"Come and meet us"}</h2></div><div className="simple-list">{content[3].map((x,i)=><div key={i}><CheckCircle2 size={18}/><span>{x}</span></div>)}{type==="contact"&&<a className="btn gold" target="_blank" rel="noreferrer" href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(business.mapQuery)}`}>Open Google Maps <MapPin size={17}/></a>}</div></div></section></Layout>;
}

function Admin() {
  const [session,setSession]=useState(null); const [ready,setReady]=useState(!supabaseConfigured); const [email,setEmail]=useState(""); const [password,setPassword]=useState(""); const [msg,setMsg]=useState("");
  useEffect(()=>{if(!supabaseConfigured)return;supabase.auth.getSession().then(({data})=>{setSession(data.session);setReady(true)});const {data:{subscription}}=supabase.auth.onAuthStateChange((_e,s)=>setSession(s));return()=>subscription.unsubscribe()},[]);
  if(!supabaseConfigured) return <AdminShell><div className="admin-login"><div className="eyebrow">OWNER DASHBOARD</div><h1>Connect Supabase first</h1><p>Add VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY to .env, then run the included database SQL.</p><a className="btn dark" href="/README.md">Read setup instructions</a></div></AdminShell>;
  if(!ready)return <AdminShell><div className="empty">Loading…</div></AdminShell>;
  if(!session)return <AdminShell><form className="admin-login" onSubmit={async e=>{e.preventDefault();setMsg("");const {error}=await supabase.auth.signInWithPassword({email,password});if(error)setMsg(error.message)}}><img className="admin-logo" src="/logo.svg"/><div className="eyebrow">PRIVATE OWNER AREA</div><h1>Admin sign in</h1><input value={email} onChange={e=>setEmail(e.target.value)} type="email" placeholder="Owner email" required/><input value={password} onChange={e=>setPassword(e.target.value)} type="password" placeholder="Password" required/><button className="btn gold">Sign in</button>{msg&&<p className="error">{msg}</p>}</form></AdminShell>;
  return <AdminDashboard session={session}/>;
}

function AdminShell({children}) { return <div className="admin-page"><div className="admin-top"><Link to="/"><img src="/logo.svg"/></Link><Link to="/vehicles">Public site</Link></div>{children}</div>; }

function AdminDashboard({session}) {
  const empty={make:"",model:"",variant:"",year:"",category:"SUV",fuel:"PETROL",transmission:"MANUAL",km_driven:"",owners:"",registration_city:"Jalgaon",price:"",status:"AVAILABLE",description:"",is_published:true};
  const [vehicles,setVehicles]=useState([]); const [form,setForm]=useState(empty); const [editing,setEditing]=useState(null); const [files,setFiles]=useState([]); const [busy,setBusy]=useState(false); const [msg,setMsg]=useState("");
  const load=()=>supabase.from("vehicles").select("*,vehicle_images(*)").order("created_at",{ascending:false}).then(({data})=>setVehicles(data||[]));
  useEffect(load,[]);
  const save=async e=>{e.preventDefault();setBusy(true);setMsg("");let payload={...form,year:form.year?Number(form.year):null,km_driven:form.km_driven?Number(form.km_driven):null,owners:form.owners?Number(form.owners):null,price:form.price?Number(form.price):null};let result;
    if(editing) result=await supabase.from("vehicles").update(payload).eq("id",editing).select().single(); else result=await supabase.from("vehicles").insert(payload).select().single();
    if(result.error){setMsg(result.error.message);setBusy(false);return}
    const id=result.data.id;
    if(files.length){for(let i=0;i<files.length;i++){const f=files[i];const path=`vehicles/${id}/${crypto.randomUUID()}-${f.name}`;const up=await supabase.storage.from("vehicle-images").upload(path,f,{upsert:false});if(up.error){setMsg(up.error.message);continue}const {data:{publicUrl}}=supabase.storage.from("vehicle-images").getPublicUrl(path);await supabase.from("vehicle_images").insert({vehicle_id:id,storage_path:path,public_url:publicUrl,is_cover:i===0,sort_order:i});}}
    setForm(empty);setFiles([]);setEditing(null);await load();setBusy(false);setMsg("Vehicle saved successfully.");
  };
  const edit=v=>{setEditing(v.id);setForm({...empty,...v});window.scrollTo({top:0,behavior:"smooth"})};
  const remove=async v=>{if(!confirm(`Delete ${v.make} ${v.model}?`))return;await supabase.from("vehicles").delete().eq("id",v.id);await load()};
  return <AdminShell><div className="container admin-content"><div className="admin-head"><div><div className="eyebrow">OWNER DASHBOARD</div><h1>Inventory manager</h1><p>Signed in as {session.user.email}</p></div><button className="btn outline dark-outline" onClick={()=>supabase.auth.signOut()}><LogOut size={17}/> Sign out</button></div>
    <form className="admin-form" onSubmit={save}><div className="admin-form-head"><h2>{editing?"Edit vehicle":"Add vehicle"}</h2>{editing&&<button type="button" className="text-link" onClick={()=>{setEditing(null);setForm(empty)}}>Cancel edit</button>}</div>
      <div className="form-grid">{["make","model","variant","year","km_driven","owners","registration_city","price"].map(k=><label key={k}>{k.replaceAll("_"," ")}<input value={form[k]??""} onChange={e=>setForm({...form,[k]:e.target.value})} type={["year","km_driven","owners","price"].includes(k)?"number":"text"} /></label>)}
      <label>Category<select value={form.category} onChange={e=>setForm({...form,category:e.target.value})}>{categories.map(c=><option key={c.key}>{c.key}</option>)}</select></label>
      <label>Fuel<select value={form.fuel} onChange={e=>setForm({...form,fuel:e.target.value})}><option>PETROL</option><option>DIESEL</option><option>CNG</option><option>HYBRID</option><option>ELECTRIC</option></select></label>
      <label>Transmission<select value={form.transmission} onChange={e=>setForm({...form,transmission:e.target.value})}><option>MANUAL</option><option>AUTOMATIC</option><option>AMT</option><option>CVT</option><option>DCT</option></select></label>
      <label>Status<select value={form.status} onChange={e=>setForm({...form,status:e.target.value})}><option>AVAILABLE</option><option>RESERVED</option><option>SOLD</option></select></label>
      <label className="full">Description<textarea value={form.description} onChange={e=>setForm({...form,description:e.target.value})}/></label>
      <label className="full upload"><Upload size={18}/> Vehicle photos<input type="file" accept="image/*" multiple onChange={e=>setFiles([...e.target.files])}/><small>{files.length ? `${files.length} selected — first image becomes cover` : "Select multiple photos from your phone."}</small></label>
      <label className="check full"><input type="checkbox" checked={form.is_published} onChange={e=>setForm({...form,is_published:e.target.checked})}/> Publish this vehicle on the public website</label></div>
      <button className="btn gold" disabled={busy}>{busy?<><span className="spinner"/> Saving…</>:<><Save size={17}/> Save vehicle</>}</button>
    </form>
    <div className="admin-table"><div className="admin-form-head"><h2>Current listings</h2><span>{vehicles.length} vehicles</span></div>{vehicles.map(v=><div className="admin-row" key={v.id}><div><strong>{v.year} {v.make} {v.model}</strong><span>{v.category} · {v.status} · {v.is_published?"Published":"Draft"}</span></div><div><button className="small-btn" onClick={()=>edit(v)}>Edit</button><button className="small-btn danger" onClick={()=>remove(v)}><Trash2 size={15}/></button></div></div>)}</div>
    {msg&&<div className="toast">{msg}</div>}
  </div></AdminShell>;
}

function App(){return <BrowserRouter><Routes><Route path="/" element={<Home/>}/><Route path="/vehicles" element={<Vehicles/>}/><Route path="/vehicles/:id" element={<VehicleDetail/>}/><Route path="/about" element={<SimplePage type="about"/>}/><Route path="/finance" element={<SimplePage type="finance"/>}/><Route path="/contact" element={<SimplePage type="contact"/>}/><Route path="/admin/*" element={<Admin/>}/><Route path="*" element={<Home/>}/></Routes></BrowserRouter>}
export default App;
